CREATE DATABASE IF NOT EXISTS DBCINEMALATTE;
USE DBCINEMALATTE;


CREATE TABLE CLIENTES (
    cliente_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100),
    email VARCHAR(150) UNIQUE NOT NULL,
    telefono VARCHAR(20),
    fecha_nacimiento DATE,
    tipo_cliente VARCHAR(50),
    comunidad_interes VARCHAR(100),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE PROVEEDORES (
    proveedor_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre_empresa VARCHAR(150) NOT NULL,
    contacto_nombre VARCHAR(100),
    telefono VARCHAR(20),
    email VARCHAR(150),
    tipo_servicio VARCHAR(100)
);


CREATE TABLE PRODUCTOS (
    producto_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    precio_venta DECIMAL(10, 2) NOT NULL,
    costo_compra DECIMAL(10, 2),
    categoria VARCHAR(50),
    stock_actual INT NOT NULL DEFAULT 0,
    es_coleccionable BOOLEAN DEFAULT FALSE,
    proveedor_id INT, -- Nuevo campo para la relación

    FOREIGN KEY (proveedor_id) REFERENCES PROVEEDORES(proveedor_id)
);


CREATE TABLE VENTAS (
    venta_id INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id INT,
    fecha_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    canal_venta VARCHAR(50) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    metodo_pago VARCHAR(50),
    estatus VARCHAR(50) NOT NULL DEFAULT 'Completada',

    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
);


CREATE TABLE DETALLE_VENTA (
    detalle_id INT PRIMARY KEY AUTO_INCREMENT,
    venta_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10, 2) NOT NULL,

    FOREIGN KEY (venta_id) REFERENCES VENTAS(venta_id),
    FOREIGN KEY (producto_id) REFERENCES PRODUCTOS(producto_id)
);


CREATE TABLE MEMBRESIAS (
    membresia_id INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id INT NOT NULL,
    nombre_plan VARCHAR(100) NOT NULL,
    costo DECIMAL(10, 2) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    estatus VARCHAR(20) DEFAULT 'Activa', 
    beneficios TEXT,

    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
);


CREATE TABLE EVENTOS (
    evento_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(150) NOT NULL,
    tipo VARCHAR(50), 
    fecha_hora DATETIME NOT NULL,
    ubicacion VARCHAR(100) NOT NULL, 
    cupo_maximo INT,
    costo_registro DECIMAL(10, 2) NOT NULL DEFAULT 0
);


CREATE TABLE REGISTRO_EVENTOS (
    registro_id INT PRIMARY KEY AUTO_INCREMENT,
    evento_id INT NOT NULL,
    cliente_id INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    monto_pagado DECIMAL(10, 2) NOT NULL,
    
    FOREIGN KEY (evento_id) REFERENCES EVENTOS(evento_id),
    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
);