-- Datos de ejemplo para Cinemalatte
-- Ejecutar después de crear la base de datos con dbcinemalatte.sql

USE dbcinemalatte;

-- Insertar proveedores de ejemplo
INSERT INTO PROVEEDORES (nombre_empresa, contacto_nombre, telefono, email, tipo_servicio) VALUES
('Tech Electronics Inc.', 'Juan Pérez', '555-0101', 'contacto@techelectronics.com', 'Electrónica'),
('Merchandise World', 'María García', '555-0102', 'info@merchandiseworld.com', 'Merchandising'),
('Digital Distributors', 'Carlos López', '555-0103', 'ventas@digitaldist.com', 'Software y Digital'),
('Cinema Supplies Co.', 'Ana Martínez', '555-0104', 'contact@cinemasupplies.com', 'Suministros de Cine');

-- Insertar productos de ejemplo
INSERT INTO PRODUCTOS (nombre, descripcion, precio_venta, costo_compra, categoria, stock_actual, es_coleccionable, proveedor_id) VALUES
('Figura Star Wars Darth Vader', 'Figura coleccionable de alta calidad', 45.99, 25.00, 'Coleccionables', 15, TRUE, 2),
('Poster Vintage Cinema', 'Poster decorativo estilo retro', 12.99, 6.50, 'Decoración', 50, FALSE, 2),
('Bluray Player 4K', 'Reproductor Bluray Ultra HD', 199.99, 120.00, 'Electrónica', 8, FALSE, 1),
('Palomitas Gourmet Pack', 'Pack de palomitas premium sabores variados', 8.99, 4.00, 'Snacks', 100, FALSE, 4),
('Funko Pop Marvel Collection', 'Figura Funko Pop edición limitada', 15.99, 8.00, 'Coleccionables', 25, TRUE, 2),
('Cable HDMI Premium 3m', 'Cable HDMI 2.1 alta velocidad', 24.99, 12.00, 'Electrónica', 30, FALSE, 1),
('Libro "Historia del Cine"', 'Libro ilustrado sobre la historia del cine', 29.99, 15.00, 'Libros', 20, FALSE, 3),
('Lampara LED Cinema Sign', 'Letrero LED decorativo CINEMA', 89.99, 45.00, 'Decoración', 5, FALSE, 1),
('Camiseta Retro Movies', 'Camiseta con diseños de películas clásicas', 19.99, 9.00, 'Ropa', 40, FALSE, 2),
('Proyector Mini Portátil', 'Proyector compacto Full HD', 299.99, 180.00, 'Electrónica', 3, FALSE, 1);

-- Insertar eventos de ejemplo
INSERT INTO EVENTOS (nombre, tipo, fecha_hora, ubicacion, cupo_maximo, costo_registro) VALUES
('Noche de Cine Clásico', 'Proyección', '2025-12-15 19:00:00', 'Sala Principal', 50, 5.00),
('Taller de Fotografía Cinematográfica', 'Taller', '2025-12-20 10:00:00', 'Aula 1', 20, 25.00),
('Lanzamiento Merchandising Exclusivo', 'Lanzamiento', '2025-12-10 18:00:00', 'Tienda', 100, 0.00),
('Charla con Director de Cine', 'Charla', '2026-01-05 17:00:00', 'Auditorio', 80, 10.00),
('Convención CinemalatteCon 2026', 'Convención', '2026-02-14 09:00:00', 'Centro de Convenciones', 200, 45.00);

-- Nota: Los clientes se registran a través de la aplicación
-- Para crear ventas y membresías, primero necesitas clientes registrados

-- Insertar un cliente de ejemplo (contraseña: password123)
-- Hash generado con bcrypt para 'password123'
INSERT INTO CLIENTES (nombre, apellido, email, password, telefono, fecha_nacimiento, tipo_cliente, comunidad_interes) VALUES
('Admin', 'Usuario', 'admin@cinemalatte.com', '$2a$08$5O8vxJKqE4vF5dVHcZHfF.rIGE3oW5xGxIGqNqC8M8KGrC5Z5nQKK', '555-9999', '1990-01-01', 'VIP', 'Cine Clásico'),
('Roberto', 'Gómez', 'roberto@email.com', '$2a$08$5O8vxJKqE4vF5dVHcZHfF.rIGE3oW5xGxIGqNqC8M8KGrC5Z5nQKK', '555-1234', '1985-05-15', 'Regular', 'Sci-Fi'),
('Laura', 'Fernández', 'laura@email.com', '$2a$08$5O8vxJKqE4vF5dVHcZHfF.rIGE3oW5xGxIGqNqC8M8KGrC5Z5nQKK', '555-5678', '1992-08-22', 'Premium', 'Marvel');

-- Insertar membresías de ejemplo
INSERT INTO MEMBRESIAS (cliente_id, nombre_plan, costo, fecha_inicio, fecha_fin, estatus, beneficios) VALUES
(1, 'VIP', 99.99, '2025-01-01', '2025-12-31', 'Activa', 'Descuento 20% en productos, Acceso prioritario a eventos, Envío gratis'),
(3, 'Premium', 49.99, '2025-06-01', '2026-06-01', 'Activa', 'Descuento 10% en productos, Acceso a eventos exclusivos');

-- Insertar una venta de ejemplo
INSERT INTO VENTAS (cliente_id, fecha_hora, canal_venta, total, metodo_pago, estatus) VALUES
(2, '2025-11-28 14:30:00', 'Online', 61.98, 'Tarjeta Crédito', 'Completada');

-- Insertar detalles de la venta
INSERT INTO DETALLE_VENTA (venta_id, producto_id, cantidad, precio_unitario) VALUES
(1, 1, 1, 45.99),  -- Figura Darth Vader
(1, 2, 1, 12.99),  -- Poster
(1, 4, 1, 8.99);   -- Palomitas

-- Actualizar stock después de la venta
UPDATE PRODUCTOS SET stock_actual = stock_actual - 1 WHERE producto_id = 1;
UPDATE PRODUCTOS SET stock_actual = stock_actual - 1 WHERE producto_id = 2;
UPDATE PRODUCTOS SET stock_actual = stock_actual - 1 WHERE producto_id = 4;

-- Insertar registros de eventos
INSERT INTO REGISTRO_EVENTOS (evento_id, cliente_id, fecha_registro, monto_pagado) VALUES
(1, 1, '2025-11-25 10:00:00', 5.00),
(1, 2, '2025-11-26 15:30:00', 5.00),
(2, 3, '2025-11-27 09:15:00', 25.00),
(3, 1, '2025-11-28 12:00:00', 0.00);

-- Consultas útiles para verificar los datos
SELECT 'Total Clientes:' as Info, COUNT(*) as Total FROM CLIENTES
UNION ALL
SELECT 'Total Proveedores:', COUNT(*) FROM PROVEEDORES
UNION ALL
SELECT 'Total Productos:', COUNT(*) FROM PRODUCTOS
UNION ALL
SELECT 'Total Ventas:', COUNT(*) FROM VENTAS
UNION ALL
SELECT 'Total Membresías:', COUNT(*) FROM MEMBRESIAS
UNION ALL
SELECT 'Total Eventos:', COUNT(*) FROM EVENTOS;
