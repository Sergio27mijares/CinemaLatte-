// Listar todos los eventos
exports.list = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query(`
      SELECT e.*, 
        (SELECT COUNT(*) FROM REGISTRO_EVENTOS WHERE evento_id = e.evento_id) as registros
      FROM EVENTOS e
      ORDER BY e.fecha_hora DESC
    `, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener eventos');
      }

      res.render('admin/eventos/list', {
        user: req.session,
        eventos: results,
        message: null
      });
    });
  });
};

// Ver detalles y registros del evento
exports.view = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM EVENTOS WHERE evento_id = ?', [id], (error, eventos) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener evento');
      }

      if (eventos.length === 0) {
        return res.status(404).send('Evento no encontrado');
      }

      connection.query(`
        SELECT r.*, c.nombre, c.apellido, c.email
        FROM REGISTRO_EVENTOS r
        JOIN CLIENTES c ON r.cliente_id = c.cliente_id
        WHERE r.evento_id = ?
        ORDER BY r.fecha_registro DESC
      `, [id], (error, registros) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al obtener registros');
        }

        res.render('admin/eventos/view', {
          user: req.session,
          evento: eventos[0],
          registros: registros,
          message: null
        });
      });
    });
  });
};

// Mostrar formulario de creación
exports.createForm = (req, res) => {
  res.render('admin/eventos/form', {
    user: req.session,
    evento: null,
    message: null
  });
};

// Crear evento
exports.create = (req, res) => {
  const { nombre, tipo, fecha_hora, ubicacion, cupo_maximo, costo_registro } = req.body;

  if (!nombre || !fecha_hora || !ubicacion) {
    return res.status(400).send('El nombre, fecha y ubicación son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('INSERT INTO EVENTOS SET ?', {
      nombre,
      tipo: tipo || null,
      fecha_hora,
      ubicacion,
      cupo_maximo: cupo_maximo || null,
      costo_registro: costo_registro || 0
    }, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al crear el evento');
      }

      res.redirect('/admin/eventos');
    });
  });
};

// Mostrar formulario de edición
exports.editForm = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM EVENTOS WHERE evento_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener evento');
      }

      if (results.length === 0) {
        return res.status(404).send('Evento no encontrado');
      }

      // Formatear fecha para el input datetime-local
      const evento = results[0];
      if (evento.fecha_hora) {
        const date = new Date(evento.fecha_hora);
        evento.fecha_hora_formatted = date.toISOString().slice(0, 16);
      }

      res.render('admin/eventos/form', {
        user: req.session,
        evento: evento,
        message: null
      });
    });
  });
};

// Actualizar evento
exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre, tipo, fecha_hora, ubicacion, cupo_maximo, costo_registro } = req.body;

  if (!nombre || !fecha_hora || !ubicacion) {
    return res.status(400).send('El nombre, fecha y ubicación son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('UPDATE EVENTOS SET ? WHERE evento_id = ?', [{
      nombre,
      tipo: tipo || null,
      fecha_hora,
      ubicacion,
      cupo_maximo: cupo_maximo || null,
      costo_registro: costo_registro || 0
    }, id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al actualizar el evento');
      }

      res.redirect('/admin/eventos');
    });
  });
};

// Eliminar evento
exports.delete = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.beginTransaction((err) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error al iniciar transacción');
      }

      // Primero eliminar los registros
      connection.query('DELETE FROM REGISTRO_EVENTOS WHERE evento_id = ?', [id], (error) => {
        if (error) {
          return connection.rollback(() => {
            console.error(error);
            res.status(500).send('Error al eliminar registros');
          });
        }

        // Luego eliminar el evento
        connection.query('DELETE FROM EVENTOS WHERE evento_id = ?', [id], (error) => {
          if (error) {
            return connection.rollback(() => {
              console.error(error);
              res.status(500).send('Error al eliminar evento');
            });
          }

          connection.commit((err) => {
            if (err) {
              return connection.rollback(() => {
                console.error(err);
                res.status(500).send('Error al confirmar transacción');
              });
            }

            res.redirect('/admin/eventos');
          });
        });
      });
    });
  });
};
