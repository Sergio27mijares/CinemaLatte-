// Listar todos los productos
exports.list = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query(`
      SELECT p.*, pr.nombre_empresa as proveedor_nombre
      FROM PRODUCTOS p
      LEFT JOIN PROVEEDORES pr ON p.proveedor_id = pr.proveedor_id
      ORDER BY p.producto_id DESC
    `, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener productos');
      }

      res.render('admin/productos/list', {
        user: req.session,
        productos: results,
        message: null
      });
    });
  });
};

// Mostrar formulario de creación
exports.createForm = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM PROVEEDORES ORDER BY nombre_empresa', (error, proveedores) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener proveedores');
      }

      res.render('admin/productos/form', {
        user: req.session,
        producto: null,
        proveedores: proveedores,
        message: null
      });
    });
  });
};

// Crear producto
exports.create = (req, res) => {
  const { nombre, descripcion, precio_venta, costo_compra, categoria, stock_actual, es_coleccionable, proveedor_id } = req.body;

  if (!nombre || !precio_venta) {
    return res.status(400).send('El nombre y precio de venta son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('INSERT INTO PRODUCTOS SET ?', {
      nombre,
      descripcion: descripcion || null,
      precio_venta,
      costo_compra: costo_compra || null,
      categoria: categoria || null,
      stock_actual: stock_actual || 0,
      es_coleccionable: es_coleccionable ? 1 : 0,
      proveedor_id: proveedor_id || null
    }, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al crear el producto');
      }

      res.redirect('/admin/productos');
    });
  });
};

// Mostrar formulario de edición
exports.editForm = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM PRODUCTOS WHERE producto_id = ?', [id], (error, productos) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener producto');
      }

      if (productos.length === 0) {
        return res.status(404).send('Producto no encontrado');
      }

      connection.query('SELECT * FROM PROVEEDORES ORDER BY nombre_empresa', (error, proveedores) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al obtener proveedores');
        }

        res.render('admin/productos/form', {
          user: req.session,
          producto: productos[0],
          proveedores: proveedores,
          message: null
        });
      });
    });
  });
};

// Actualizar producto
exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre, descripcion, precio_venta, costo_compra, categoria, stock_actual, es_coleccionable, proveedor_id } = req.body;

  if (!nombre || !precio_venta) {
    return res.status(400).send('El nombre y precio de venta son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('UPDATE PRODUCTOS SET ? WHERE producto_id = ?', [{
      nombre,
      descripcion: descripcion || null,
      precio_venta,
      costo_compra: costo_compra || null,
      categoria: categoria || null,
      stock_actual: stock_actual || 0,
      es_coleccionable: es_coleccionable ? 1 : 0,
      proveedor_id: proveedor_id || null
    }, id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al actualizar el producto');
      }

      res.redirect('/admin/productos');
    });
  });
};

// Eliminar producto
exports.delete = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('DELETE FROM PRODUCTOS WHERE producto_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al eliminar el producto');
      }

      res.redirect('/admin/productos');
    });
  });
};
