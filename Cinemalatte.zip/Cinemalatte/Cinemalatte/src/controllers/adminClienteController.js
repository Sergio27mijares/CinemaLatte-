// Listar todos los clientes
exports.list = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM CLIENTES ORDER BY cliente_id DESC', (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener clientes');
      }

      res.render('admin/clientes/list', {
        user: req.session,
        clientes: results,
        message: null
      });
    });
  });
};

// Ver detalle del cliente
exports.view = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM CLIENTES WHERE cliente_id = ?', [id], (error, clientes) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener cliente');
      }

      if (clientes.length === 0) {
        return res.status(404).send('Cliente no encontrado');
      }

      // Obtener membresías del cliente
      connection.query('SELECT * FROM MEMBRESIAS WHERE cliente_id = ?', [id], (error, membresias) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al obtener membresías');
        }

        // Obtener compras del cliente
        connection.query('SELECT * FROM VENTAS WHERE cliente_id = ? ORDER BY fecha_hora DESC', [id], (error, ventas) => {
          if (error) {
            console.error(error);
            return res.status(500).send('Error al obtener ventas');
          }

          res.render('admin/clientes/view', {
            user: req.session,
            cliente: clientes[0],
            membresias: membresias,
            ventas: ventas,
            message: null
          });
        });
      });
    });
  });
};

// Mostrar formulario de edición
exports.editForm = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM CLIENTES WHERE cliente_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener cliente');
      }

      if (results.length === 0) {
        return res.status(404).send('Cliente no encontrado');
      }

      res.render('admin/clientes/form', {
        user: req.session,
        cliente: results[0],
        message: null
      });
    });
  });
};

// Actualizar cliente
exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre, apellido, email, telefono, fecha_nacimiento, tipo_cliente, comunidad_interes } = req.body;

  if (!nombre || !email) {
    return res.status(400).send('El nombre y email son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('UPDATE CLIENTES SET ? WHERE cliente_id = ?', [{
      nombre,
      apellido: apellido || null,
      email,
      telefono: telefono || null,
      fecha_nacimiento: fecha_nacimiento || null,
      tipo_cliente: tipo_cliente || null,
      comunidad_interes: comunidad_interes || null
    }, id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al actualizar el cliente');
      }

      res.redirect('/admin/clientes');
    });
  });
};

// Eliminar cliente
exports.delete = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('DELETE FROM CLIENTES WHERE cliente_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al eliminar el cliente. Puede tener registros asociados.');
      }

      res.redirect('/admin/clientes');
    });
  });
};
