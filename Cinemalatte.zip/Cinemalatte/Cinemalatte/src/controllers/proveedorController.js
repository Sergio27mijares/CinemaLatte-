// Listar todos los proveedores
exports.list = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM PROVEEDORES ORDER BY proveedor_id DESC', (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener proveedores');
      }

      res.render('admin/proveedores/list', {
        user: req.session,
        proveedores: results,
        message: null
      });
    });
  });
};

// Mostrar formulario de creación
exports.createForm = (req, res) => {
  res.render('admin/proveedores/form', {
    user: req.session,
    proveedor: null,
    message: null
  });
};

// Crear proveedor
exports.create = (req, res) => {
  const { nombre_empresa, contacto_nombre, telefono, email, tipo_servicio } = req.body;

  if (!nombre_empresa) {
    return res.status(400).render('admin/proveedores/form', {
      user: req.session,
      proveedor: null,
      message: 'El nombre de la empresa es requerido'
    });
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('INSERT INTO PROVEEDORES SET ?', {
      nombre_empresa,
      contacto_nombre: contacto_nombre || null,
      telefono: telefono || null,
      email: email || null,
      tipo_servicio: tipo_servicio || null
    }, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).render('admin/proveedores/form', {
          user: req.session,
          proveedor: null,
          message: 'Error al crear el proveedor'
        });
      }

      res.redirect('/admin/proveedores');
    });
  });
};

// Mostrar formulario de edición
exports.editForm = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM PROVEEDORES WHERE proveedor_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener proveedor');
      }

      if (results.length === 0) {
        return res.status(404).send('Proveedor no encontrado');
      }

      res.render('admin/proveedores/form', {
        user: req.session,
        proveedor: results[0],
        message: null
      });
    });
  });
};

// Actualizar proveedor
exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre_empresa, contacto_nombre, telefono, email, tipo_servicio } = req.body;

  if (!nombre_empresa) {
    return res.status(400).send('El nombre de la empresa es requerido');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('UPDATE PROVEEDORES SET ? WHERE proveedor_id = ?', [{
      nombre_empresa,
      contacto_nombre: contacto_nombre || null,
      telefono: telefono || null,
      email: email || null,
      tipo_servicio: tipo_servicio || null
    }, id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al actualizar el proveedor');
      }

      res.redirect('/admin/proveedores');
    });
  });
};

// Eliminar proveedor
exports.delete = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('DELETE FROM PROVEEDORES WHERE proveedor_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al eliminar el proveedor');
      }

      res.redirect('/admin/proveedores');
    });
  });
};
