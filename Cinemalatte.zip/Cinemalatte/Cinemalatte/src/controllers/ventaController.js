// Listar todas las ventas
exports.list = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query(`
      SELECT v.*, c.nombre, c.apellido, c.email
      FROM VENTAS v
      LEFT JOIN CLIENTES c ON v.cliente_id = c.cliente_id
      ORDER BY v.venta_id DESC
    `, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener ventas');
      }

      res.render('admin/ventas/list', {
        user: req.session,
        ventas: results,
        message: null
      });
    });
  });
};

// Ver detalle de venta
exports.view = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query(`
      SELECT v.*, c.nombre, c.apellido, c.email
      FROM VENTAS v
      LEFT JOIN CLIENTES c ON v.cliente_id = c.cliente_id
      WHERE v.venta_id = ?
    `, [id], (error, ventas) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener venta');
      }

      if (ventas.length === 0) {
        return res.status(404).send('Venta no encontrada');
      }

      connection.query(`
        SELECT dv.*, p.nombre as producto_nombre
        FROM DETALLE_VENTA dv
        JOIN PRODUCTOS p ON dv.producto_id = p.producto_id
        WHERE dv.venta_id = ?
      `, [id], (error, detalles) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al obtener detalles');
        }

        res.render('admin/ventas/view', {
          user: req.session,
          venta: ventas[0],
          detalles: detalles,
          message: null
        });
      });
    });
  });
};

// Mostrar formulario de creación
exports.createForm = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM CLIENTES ORDER BY nombre', (error, clientes) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener clientes');
      }

      connection.query('SELECT * FROM PRODUCTOS WHERE stock_actual > 0 ORDER BY nombre', (error, productos) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al obtener productos');
        }

        res.render('admin/ventas/form', {
          user: req.session,
          clientes: clientes,
          productos: productos,
          message: null
        });
      });
    });
  });
};

// Crear venta
exports.create = (req, res) => {
  const { cliente_id, canal_venta, metodo_pago, productos } = req.body;

  if (!canal_venta || !productos || productos.length === 0) {
    return res.status(400).send('Datos incompletos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    // Calcular total
    let total = 0;
    const productosArray = Array.isArray(productos) ? productos : [productos];
    
    connection.beginTransaction((err) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error al iniciar transacción');
      }

      // Insertar venta
      connection.query('INSERT INTO VENTAS SET ?', {
        cliente_id: cliente_id || null,
        canal_venta,
        total: 0,
        metodo_pago: metodo_pago || null,
        estatus: 'Completada'
      }, (error, result) => {
        if (error) {
          return connection.rollback(() => {
            console.error(error);
            res.status(500).send('Error al crear venta');
          });
        }

        const venta_id = result.insertId;
        let completed = 0;

        productosArray.forEach((prod) => {
          const producto_id = prod.producto_id;
          const cantidad = parseInt(prod.cantidad);
          const precio_unitario = parseFloat(prod.precio_unitario);

          total += cantidad * precio_unitario;

          // Insertar detalle
          connection.query('INSERT INTO DETALLE_VENTA SET ?', {
            venta_id,
            producto_id,
            cantidad,
            precio_unitario
          }, (error) => {
            if (error) {
              return connection.rollback(() => {
                console.error(error);
                res.status(500).send('Error al crear detalle de venta');
              });
            }

            // Actualizar stock
            connection.query('UPDATE PRODUCTOS SET stock_actual = stock_actual - ? WHERE producto_id = ?', 
              [cantidad, producto_id], (error) => {
                if (error) {
                  return connection.rollback(() => {
                    console.error(error);
                    res.status(500).send('Error al actualizar stock');
                  });
                }

                completed++;
                if (completed === productosArray.length) {
                  // Actualizar total de la venta
                  connection.query('UPDATE VENTAS SET total = ? WHERE venta_id = ?', [total, venta_id], (error) => {
                    if (error) {
                      return connection.rollback(() => {
                        console.error(error);
                        res.status(500).send('Error al actualizar total');
                      });
                    }

                    connection.commit((err) => {
                      if (err) {
                        return connection.rollback(() => {
                          console.error(err);
                          res.status(500).send('Error al confirmar transacción');
                        });
                      }

                      res.redirect('/admin/ventas');
                    });
                  });
                }
              });
          });
        });
      });
    });
  });
};

// Eliminar venta
exports.delete = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.beginTransaction((err) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error al iniciar transacción');
      }

      // Primero eliminar los detalles
      connection.query('DELETE FROM DETALLE_VENTA WHERE venta_id = ?', [id], (error) => {
        if (error) {
          return connection.rollback(() => {
            console.error(error);
            res.status(500).send('Error al eliminar detalles');
          });
        }

        // Luego eliminar la venta
        connection.query('DELETE FROM VENTAS WHERE venta_id = ?', [id], (error) => {
          if (error) {
            return connection.rollback(() => {
              console.error(error);
              res.status(500).send('Error al eliminar venta');
            });
          }

          connection.commit((err) => {
            if (err) {
              return connection.rollback(() => {
                console.error(err);
                res.status(500).send('Error al confirmar transacción');
              });
            }

            res.redirect('/admin/ventas');
          });
        });
      });
    });
  });
};
