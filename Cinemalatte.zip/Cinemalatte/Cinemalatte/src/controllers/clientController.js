﻿exports.isLoggedIn = (req, res, next) => {
  if (req.session.clienteId) {
    next();
  } else {
    return res.redirect('/');
  }
};

exports.dashboard = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).render('dashboard', {
        user: req.session,
        message: 'Error de servidor'
      });
    }

    connection.query('SELECT * FROM CLIENTES WHERE cliente_id = ?', [req.session.clienteId], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).render('dashboard', {
          user: req.session,
          message: 'Error al cargar datos'
        });
      }

      res.render('dashboard', {
        user: results[0] || req.session
      });
    });
  });
};
