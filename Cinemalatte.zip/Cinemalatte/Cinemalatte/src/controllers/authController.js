﻿const bcrypt = require('bcryptjs');

exports.register = (req, res) => {
  const { nombre, apellido, email, password, confirmPassword, telefono } = req.body;

  if (!nombre || !email || !password || !confirmPassword) {
    return res.status(400).render('register', {
      message: 'Por favor completa todos los campos'
    });
  }

  if (password !== confirmPassword) {
    return res.status(400).render('register', {
      message: 'Las contraseñas no coinciden'
    });
  }

  if (password.length < 8) {
    return res.status(400).render('register', {
      message: 'La contraseña debe tener al menos 8 caracteres'
    });
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).render('register', {
        message: 'Error de servidor'
      });
    }

    connection.query('SELECT email FROM CLIENTES WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).render('register', {
          message: 'Error de servidor'
        });
      }

      if (results.length > 0) {
        return res.status(400).render('register', {
          message: 'El email ya está registrado'
        });
      }

      const passwordHash = await bcrypt.hash(password, 8);

      connection.query('INSERT INTO CLIENTES SET ?', {
        nombre: nombre,
        apellido: apellido,
        email: email,
        password: passwordHash,
        telefono: telefono || null,
        fecha_registro: new Date()
      }, (error, results) => {
        if (error) {
          console.error(error);
          return res.status(500).render('register', {
            message: 'Error al registrar el cliente'
          });
        }

        return res.status(201).render('register', {
          message: 'Usuario registrado correctamente. Inicia sesión'
        });
      });
    });
  });
};

exports.login = (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).render('login', {
      message: 'Por favor completa todos los campos'
    });
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).render('login', {
        message: 'Error de servidor'
      });
    }

    connection.query('SELECT * FROM CLIENTES WHERE email = ?', [email], async (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).render('login', {
          message: 'Error de servidor'
        });
      }

      if (results.length === 0 || !(await bcrypt.compare(password, results[0].password))) {
        return res.status(401).render('login', {
          message: 'Email o contraseña incorrectos'
        });
      }

      req.session.clienteId = results[0].cliente_id;
      req.session.nombre = results[0].nombre;
      req.session.email = results[0].email;

      return res.status(200).redirect('/clients/dashboard');
    });
  });
};

exports.logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).render('index', {
        message: 'No se pudo cerrar sesión'
      });
    }
    return res.redirect('/');
  });
};
