// Listar todas las membresías
exports.list = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query(`
      SELECT m.*, c.nombre, c.apellido, c.email
      FROM MEMBRESIAS m
      JOIN CLIENTES c ON m.cliente_id = c.cliente_id
      ORDER BY m.membresia_id DESC
    `, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener membresías');
      }

      res.render('admin/membresias/list', {
        user: req.session,
        membresias: results,
        message: null
      });
    });
  });
};

// Mostrar formulario de creación
exports.createForm = (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM CLIENTES ORDER BY nombre', (error, clientes) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener clientes');
      }

      res.render('admin/membresias/form', {
        user: req.session,
        membresia: null,
        clientes: clientes,
        message: null
      });
    });
  });
};

// Crear membresía
exports.create = (req, res) => {
  const { cliente_id, nombre_plan, costo, fecha_inicio, fecha_fin, beneficios, estatus } = req.body;

  if (!cliente_id || !nombre_plan || !costo || !fecha_inicio || !fecha_fin) {
    return res.status(400).send('Todos los campos son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('INSERT INTO MEMBRESIAS SET ?', {
      cliente_id,
      nombre_plan,
      costo,
      fecha_inicio,
      fecha_fin,
      estatus: estatus || 'Activa',
      beneficios: beneficios || null
    }, (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al crear la membresía');
      }

      res.redirect('/admin/membresias');
    });
  });
};

// Mostrar formulario de edición
exports.editForm = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('SELECT * FROM MEMBRESIAS WHERE membresia_id = ?', [id], (error, membresias) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al obtener membresía');
      }

      if (membresias.length === 0) {
        return res.status(404).send('Membresía no encontrada');
      }

      connection.query('SELECT * FROM CLIENTES ORDER BY nombre', (error, clientes) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al obtener clientes');
        }

        res.render('admin/membresias/form', {
          user: req.session,
          membresia: membresias[0],
          clientes: clientes,
          message: null
        });
      });
    });
  });
};

// Actualizar membresía
exports.update = (req, res) => {
  const { id } = req.params;
  const { cliente_id, nombre_plan, costo, fecha_inicio, fecha_fin, beneficios, estatus } = req.body;

  if (!cliente_id || !nombre_plan || !costo || !fecha_inicio || !fecha_fin) {
    return res.status(400).send('Todos los campos son requeridos');
  }

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('UPDATE MEMBRESIAS SET ? WHERE membresia_id = ?', [{
      cliente_id,
      nombre_plan,
      costo,
      fecha_inicio,
      fecha_fin,
      estatus: estatus || 'Activa',
      beneficios: beneficios || null
    }, id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al actualizar la membresía');
      }

      res.redirect('/admin/membresias');
    });
  });
};

// Eliminar membresía
exports.delete = (req, res) => {
  const { id } = req.params;

  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    connection.query('DELETE FROM MEMBRESIAS WHERE membresia_id = ?', [id], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error al eliminar la membresía');
      }

      res.redirect('/admin/membresias');
    });
  });
};
