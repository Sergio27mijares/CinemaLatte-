const express = require('express');
const router = express.Router();
const proveedorController = require('../../controllers/proveedorController');

// Middleware para verificar si está autenticado (reutilizamos del clientController)
const { isLoggedIn } = require('../../controllers/clientController');

// Listar proveedores
router.get('/', isLoggedIn, proveedorController.list);

// Formulario de creación
router.get('/create', isLoggedIn, proveedorController.createForm);

// Crear proveedor
router.post('/create', isLoggedIn, proveedorController.create);

// Formulario de edición
router.get('/edit/:id', isLoggedIn, proveedorController.editForm);

// Actualizar proveedor
router.post('/edit/:id', isLoggedIn, proveedorController.update);

// Eliminar proveedor
router.post('/delete/:id', isLoggedIn, proveedorController.delete);

module.exports = router;
