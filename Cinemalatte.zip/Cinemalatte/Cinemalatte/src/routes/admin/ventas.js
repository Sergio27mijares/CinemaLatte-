const express = require('express');
const router = express.Router();
const ventaController = require('../../controllers/ventaController');

const { isLoggedIn } = require('../../controllers/clientController');

// Listar ventas
router.get('/', isLoggedIn, ventaController.list);

// Ver detalle de venta
router.get('/view/:id', isLoggedIn, ventaController.view);

// Formulario de creación
router.get('/create', isLoggedIn, ventaController.createForm);

// Crear venta
router.post('/create', isLoggedIn, ventaController.create);

// Eliminar venta
router.post('/delete/:id', isLoggedIn, ventaController.delete);

module.exports = router;
