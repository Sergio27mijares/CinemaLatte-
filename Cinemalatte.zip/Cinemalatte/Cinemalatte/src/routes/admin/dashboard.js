const express = require('express');
const router = express.Router();
const { isLoggedIn } = require('../../controllers/clientController');

// Dashboard de administración
router.get('/', isLoggedIn, (req, res) => {
  req.getConnection((err, connection) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error de servidor');
    }

    // Obtener estadísticas
    const queries = {
      totalClientes: 'SELECT COUNT(*) as total FROM CLIENTES',
      totalProductos: 'SELECT COUNT(*) as total FROM PRODUCTOS',
      totalVentas: 'SELECT COUNT(*) as total FROM VENTAS',
      totalEventos: 'SELECT COUNT(*) as total FROM EVENTOS',
      ventasRecientes: 'SELECT v.*, c.nombre, c.apellido FROM VENTAS v LEFT JOIN CLIENTES c ON v.cliente_id = c.cliente_id ORDER BY v.fecha_hora DESC LIMIT 5',
      stockBajo: 'SELECT * FROM PRODUCTOS WHERE stock_actual < 10 ORDER BY stock_actual ASC LIMIT 5'
    };

    connection.query(queries.totalClientes, (err, clientes) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error al obtener estadísticas');
      }

      connection.query(queries.totalProductos, (err, productos) => {
        if (err) {
          console.error(err);
          return res.status(500).send('Error al obtener estadísticas');
        }

        connection.query(queries.totalVentas, (err, ventas) => {
          if (err) {
            console.error(err);
            return res.status(500).send('Error al obtener estadísticas');
          }

          connection.query(queries.totalEventos, (err, eventos) => {
            if (err) {
              console.error(err);
              return res.status(500).send('Error al obtener estadísticas');
            }

            connection.query(queries.ventasRecientes, (err, ventasRecientes) => {
              if (err) {
                console.error(err);
                return res.status(500).send('Error al obtener ventas recientes');
              }

              connection.query(queries.stockBajo, (err, stockBajo) => {
                if (err) {
                  console.error(err);
                  return res.status(500).send('Error al obtener productos con stock bajo');
                }

                res.render('admin/dashboard', {
                  user: req.session,
                  stats: {
                    clientes: clientes[0].total,
                    productos: productos[0].total,
                    ventas: ventas[0].total,
                    eventos: eventos[0].total
                  },
                  ventasRecientes: ventasRecientes,
                  stockBajo: stockBajo
                });
              });
            });
          });
        });
      });
    });
  });
});

module.exports = router;
