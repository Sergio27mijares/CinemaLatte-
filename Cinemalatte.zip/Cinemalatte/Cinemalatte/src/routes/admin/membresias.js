const express = require('express');
const router = express.Router();
const membresiaController = require('../../controllers/membresiaController');

const { isLoggedIn } = require('../../controllers/clientController');

// Listar membresías
router.get('/', isLoggedIn, membresiaController.list);

// Formulario de creación
router.get('/create', isLoggedIn, membresiaController.createForm);

// Crear membresía
router.post('/create', isLoggedIn, membresiaController.create);

// Formulario de edición
router.get('/edit/:id', isLoggedIn, membresiaController.editForm);

// Actualizar membresía
router.post('/edit/:id', isLoggedIn, membresiaController.update);

// Eliminar membresía
router.post('/delete/:id', isLoggedIn, membresiaController.delete);

module.exports = router;
