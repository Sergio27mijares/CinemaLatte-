const express = require('express');
const router = express.Router();
const productoController = require('../../controllers/productoController');

const { isLoggedIn } = require('../../controllers/clientController');

// Listar productos
router.get('/', isLoggedIn, productoController.list);

// Formulario de creación
router.get('/create', isLoggedIn, productoController.createForm);

// Crear producto
router.post('/create', isLoggedIn, productoController.create);

// Formulario de edición
router.get('/edit/:id', isLoggedIn, productoController.editForm);

// Actualizar producto
router.post('/edit/:id', isLoggedIn, productoController.update);

// Eliminar producto
router.post('/delete/:id', isLoggedIn, productoController.delete);

module.exports = router;
