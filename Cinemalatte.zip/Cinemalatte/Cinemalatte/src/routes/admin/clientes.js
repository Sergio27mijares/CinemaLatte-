const express = require('express');
const router = express.Router();
const adminClienteController = require('../../controllers/adminClienteController');

const { isLoggedIn } = require('../../controllers/clientController');

// Listar clientes
router.get('/', isLoggedIn, adminClienteController.list);

// Ver detalle de cliente
router.get('/view/:id', isLoggedIn, adminClienteController.view);

// Formulario de edición
router.get('/edit/:id', isLoggedIn, adminClienteController.editForm);

// Actualizar cliente
router.post('/edit/:id', isLoggedIn, adminClienteController.update);

// Eliminar cliente
router.post('/delete/:id', isLoggedIn, adminClienteController.delete);

module.exports = router;
