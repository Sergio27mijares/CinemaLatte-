const express = require('express');
const router = express.Router();
const eventoController = require('../../controllers/eventoController');

const { isLoggedIn } = require('../../controllers/clientController');

// Listar eventos
router.get('/', isLoggedIn, eventoController.list);

// Ver detalle de evento
router.get('/view/:id', isLoggedIn, eventoController.view);

// Formulario de creación
router.get('/create', isLoggedIn, eventoController.createForm);

// Crear evento
router.post('/create', isLoggedIn, eventoController.create);

// Formulario de edición
router.get('/edit/:id', isLoggedIn, eventoController.editForm);

// Actualizar evento
router.post('/edit/:id', isLoggedIn, eventoController.update);

// Eliminar evento
router.post('/delete/:id', isLoggedIn, eventoController.delete);

module.exports = router;
