# 🎬 Guía Rápida de Inicio - Cinemalatte

## 📋 Requisitos Previos

- Node.js instalado (v14 o superior)
- MySQL instalado y ejecutándose
- Terminal/PowerShell

## 🚀 Pasos para Iniciar el Proyecto

### 1. Configurar la Base de Datos

```sql
-- Abrir MySQL y ejecutar los siguientes archivos en orden:

-- 1. Crear la base de datos y tablas
mysql -u root -p < db/dbcinemalatte.sql

-- 2. (Opcional) Insertar datos de ejemplo
mysql -u root -p < db/datos_ejemplo.sql
```

**O manualmente en MySQL Workbench/phpMyAdmin:**
- Importar `db/dbcinemalatte.sql`
- Importar `db/datos_ejemplo.sql` (opcional)

### 2. Configurar Variables de Entorno

El archivo `.env` ya está configurado. Si necesitas cambiar la configuración:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=tu_contraseña_mysql
DB_NAME=dbcinemalatte
DB_PORT=3306
SESSION_SECRET=cinemalatte_secreto_seguro_123
NODE_ENV=development
PORT=8080
```

### 3. Instalar Dependencias

```bash
npm install
```

### 4. Iniciar el Servidor

**Modo desarrollo (con nodemon):**
```bash
npm run dev
```

**Modo producción:**
```bash
npm start
```

El servidor estará disponible en: `http://localhost:8080`

## 🔐 Credenciales de Prueba

Si ejecutaste `datos_ejemplo.sql`, puedes usar estas credenciales:

**Usuario Admin/VIP:**
- Email: `admin@cinemalatte.com`
- Contraseña: `password123`

**Usuario Regular:**
- Email: `roberto@email.com`
- Contraseña: `password123`

**Usuario Premium:**
- Email: `laura@email.com`
- Contraseña: `password123`

## 🗺️ Rutas Principales

### Públicas
- `/` - Página de inicio (redirige a login)
- `/auth/register` - Registro de nuevos usuarios
- `/auth/login` - Inicio de sesión

### Área de Cliente
- `/clients/dashboard` - Dashboard del cliente

### Panel de Administración
- `/admin/dashboard` - Dashboard principal con estadísticas
- `/admin/clientes` - Gestión de clientes
- `/admin/productos` - Gestión de productos
- `/admin/proveedores` - Gestión de proveedores
- `/admin/ventas` - Gestión de ventas
- `/admin/membresias` - Gestión de membresías
- `/admin/eventos` - Gestión de eventos

## 📦 Funcionalidades Disponibles

### ✅ Gestión de Clientes
- Listar, ver, editar y eliminar clientes
- Ver historial de compras y membresías

### ✅ Gestión de Productos
- CRUD completo de productos
- Control de stock
- Asociación con proveedores
- Marca de productos coleccionables

### ✅ Gestión de Proveedores
- CRUD completo de proveedores
- Información de contacto y tipo de servicio

### ✅ Gestión de Ventas
- Crear ventas con múltiples productos
- Actualización automática de stock
- Ver detalles de ventas
- Asociar ventas a clientes

### ✅ Gestión de Membresías
- CRUD completo de membresías
- Planes: Básico, Premium, VIP, Coleccionista
- Estados: Activa, Pendiente, Expirada, Cancelada

### ✅ Gestión de Eventos
- CRUD completo de eventos
- Tipos: Proyección, Taller, Charla, Lanzamiento, Convención
- Control de cupo y registros
- Ver lista de participantes

### ✅ Dashboard Administrativo
- Estadísticas en tiempo real
- Ventas recientes
- Alertas de stock bajo
- Navegación rápida entre módulos

## 🛠️ Solución de Problemas Comunes

### Error de conexión a la base de datos
```
Error: connect ECONNREFUSED
```
**Solución:** Verifica que MySQL esté ejecutándose y las credenciales en `.env` sean correctas.

### Error "Cannot find module"
```
Error: Cannot find module 'express'
```
**Solución:** Ejecuta `npm install` para instalar las dependencias.

### Puerto 8080 en uso
```
Error: listen EADDRINUSE: address already in use :::8080
```
**Solución:** Cambia el puerto en `.env` o detén el proceso que usa el puerto 8080.

### Sesión no se mantiene
**Solución:** Verifica que `SESSION_SECRET` esté configurado en `.env`.

## 📚 Estructura del Proyecto

```
Cinemalatte/
├── app.js                 # Archivo principal
├── package.json           # Dependencias
├── .env                   # Variables de entorno
├── ADMIN_README.md        # Documentación del admin
├── QUICK_START.md         # Esta guía
├── db/
│   ├── dbcinemalatte.sql  # Estructura de BD
│   └── datos_ejemplo.sql  # Datos de prueba
└── src/
    ├── controllers/       # Lógica de negocio
    ├── routes/           # Definición de rutas
    │   └── admin/        # Rutas del panel admin
    ├── views/            # Plantillas EJS
    │   └── admin/        # Vistas del panel admin
    └── public/           # Archivos estáticos
        └── css/          # Estilos CSS
```

## 📞 Soporte

Para más información, consulta:
- `ADMIN_README.md` - Documentación completa del sistema de administración
- `README` - Documentación general del proyecto

## ✨ Próximos Pasos Recomendados

1. Explora el dashboard de administración
2. Crea algunos productos y proveedores
3. Registra una venta de prueba
4. Crea un evento y registra participantes
5. Explora las diferentes vistas y funcionalidades

¡Disfruta usando Cinemalatte! 🎬🍿
