﻿
require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const myConnection = require('express-myconnection');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const authRoutes = require('./src/routes/auth');
const clientRoutes = require('./src/routes/clients');

// Rutas de administración
const adminDashboardRoutes = require('./src/routes/admin/dashboard');
const adminClientesRoutes = require('./src/routes/admin/clientes');
const adminProveedoresRoutes = require('./src/routes/admin/proveedores');
const adminProductosRoutes = require('./src/routes/admin/productos');
const adminVentasRoutes = require('./src/routes/admin/ventas');
const adminMembresiasRoutes = require('./src/routes/admin/membresias');
const adminEventosRoutes = require('./src/routes/admin/eventos');

const app = express();

app.use(myConnection(mysql, {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME
}, 'pool'));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'src/public')));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,
    maxAge: 1000 * 60 * 60 * 24
  }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src/views'));

app.use('/auth', authRoutes);
app.use('/clients', clientRoutes);

// Rutas de administración
app.use('/admin/dashboard', adminDashboardRoutes);
app.use('/admin/clientes', adminClientesRoutes);
app.use('/admin/proveedores', adminProveedoresRoutes);
app.use('/admin/productos', adminProductosRoutes);
app.use('/admin/ventas', adminVentasRoutes);
app.use('/admin/membresias', adminMembresiasRoutes);
app.use('/admin/eventos', adminEventosRoutes);

app.get('/', (req, res) => {
  if (req.session && req.session.clienteId) {
    return res.redirect('/clients/dashboard');
  }
  res.render('login', { message: null });
});


app.get('/ping', (req, res) => res.send('pong'));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log('Servidor ejecutándose en http://localhost:' + PORT);
});
