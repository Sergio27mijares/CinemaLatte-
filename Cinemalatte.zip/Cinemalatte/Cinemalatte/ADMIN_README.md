# Sistema de Administración - Cinemalatte

## CRUDs Implementados

Se han creado todos los CRUDs necesarios para la administración completa del sistema Cinemalatte:

### 1. **Gestión de Clientes** (`/admin/clientes`)
- Listar todos los clientes
- Ver detalle de cliente (con membresías y compras)
- Editar información del cliente
- Eliminar cliente

### 2. **Gestión de Proveedores** (`/admin/proveedores`)
- Listar proveedores
- Crear nuevo proveedor
- Editar proveedor existente
- Eliminar proveedor

### 3. **Gestión de Productos** (`/admin/productos`)
- Listar productos con stock
- Crear nuevo producto
- Editar producto existente
- Eliminar producto
- Asociar productos con proveedores

### 4. **Gestión de Ventas** (`/admin/ventas`)
- Listar todas las ventas
- Ver detalle de venta con productos
- Crear nueva venta (con múltiples productos)
- Eliminar venta
- Actualización automática de stock

### 5. **Gestión de Membresías** (`/admin/membresias`)
- Listar membresías
- Crear nueva membresía para clientes
- Editar membresía existente
- Eliminar membresía
- Estados: Activa, Pendiente, Expirada, Cancelada

### 6. **Gestión de Eventos** (`/admin/eventos`)
- Listar eventos
- Ver detalle de evento con registros
- Crear nuevo evento
- Editar evento existente
- Eliminar evento
- Ver participantes registrados

### 7. **Dashboard de Administración** (`/admin/dashboard`)
- Estadísticas generales (clientes, productos, ventas, eventos)
- Ventas recientes
- Alertas de stock bajo
- Resumen visual del sistema

## Estructura de Archivos Creados

```
src/
├── controllers/
│   ├── adminClienteController.js
│   ├── proveedorController.js
│   ├── productoController.js
│   ├── ventaController.js
│   ├── membresiaController.js
│   └── eventoController.js
├── routes/
│   └── admin/
│       ├── dashboard.js
│       ├── clientes.js
│       ├── proveedores.js
│       ├── productos.js
│       ├── ventas.js
│       ├── membresias.js
│       └── eventos.js
└── views/
    └── admin/
        ├── dashboard.ejs
        ├── clientes/
        │   ├── list.ejs
        │   ├── form.ejs
        │   └── view.ejs
        ├── proveedores/
        │   ├── list.ejs
        │   └── form.ejs
        ├── productos/
        │   ├── list.ejs
        │   └── form.ejs
        ├── ventas/
        │   ├── list.ejs
        │   ├── form.ejs
        │   └── view.ejs
        ├── membresias/
        │   ├── list.ejs
        │   └── form.ejs
        └── eventos/
            ├── list.ejs
            ├── form.ejs
            └── view.ejs
```

## Acceso al Panel de Administración

1. **Iniciar sesión**: El usuario debe autenticarse en `/auth/login`
2. **Acceder al dashboard**: Una vez autenticado, ir a `/admin/dashboard`
3. **Navegación**: Usa el menú superior para acceder a cada módulo

## Rutas Principales

| Módulo | Ruta Base | Funcionalidades |
|--------|-----------|-----------------|
| Dashboard | `/admin/dashboard` | Vista general y estadísticas |
| Clientes | `/admin/clientes` | CRUD completo + vista detallada |
| Proveedores | `/admin/proveedores` | CRUD completo |
| Productos | `/admin/productos` | CRUD completo |
| Ventas | `/admin/ventas` | Crear, listar, ver detalle, eliminar |
| Membresías | `/admin/membresias` | CRUD completo |
| Eventos | `/admin/eventos` | CRUD completo + registros |

## Características Implementadas

### Seguridad
- Middleware de autenticación (`isLoggedIn`) en todas las rutas admin
- Validación de sesión antes de permitir acceso

### Funcionalidades Avanzadas
- **Ventas**: Manejo de transacciones con múltiples productos
- **Stock**: Actualización automática al crear ventas
- **Relaciones**: Productos vinculados a proveedores
- **Eventos**: Seguimiento de participantes registrados
- **Dashboard**: Alertas de stock bajo, estadísticas en tiempo real

### Interfaz de Usuario
- Diseño responsive con CSS moderno
- Navegación intuitiva entre módulos
- Formularios validados
- Confirmaciones antes de eliminar
- Mensajes de error y éxito

## Cómo Usar

1. **Iniciar el servidor**:
```bash
npm start
```

2. **Acceder al sistema**:
   - Registro: `http://localhost:8080/auth/register`
   - Login: `http://localhost:8080/auth/login`
   - Dashboard Admin: `http://localhost:8080/admin/dashboard`

3. **Gestionar entidades**:
   - Navega usando el menú superior
   - Usa los botones "+" para crear nuevos registros
   - Edita o elimina desde las tablas de listado

## Próximas Mejoras Sugeridas

- [ ] Agregar campo de rol (admin/cliente) en la tabla CLIENTES
- [ ] Middleware específico para verificar rol de administrador
- [ ] Paginación en listados largos
- [ ] Búsqueda y filtros avanzados
- [ ] Exportación de reportes (PDF, Excel)
- [ ] Gráficas interactivas en el dashboard
- [ ] Sistema de notificaciones
- [ ] Historial de cambios (audit log)

## Notas Importantes

- Actualmente, cualquier usuario autenticado puede acceder al panel admin
- Se recomienda agregar un campo `rol` o `es_admin` a la tabla CLIENTES
- Las contraseñas están hasheadas con bcrypt
- Las sesiones expiran después de 24 horas
